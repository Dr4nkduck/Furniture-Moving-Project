package SWP301.Furniture_Moving_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FurnitureMovingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
