package SWP301.Furniture_Moving_Project.model;

public enum AccountStatus {
    ACTIVE, SUSPENDED, DELETED
}
