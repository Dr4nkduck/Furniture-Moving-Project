package SWP301.Furniture_Moving_Project.model;

public interface RoleNameOnly {
    String getRoleName();
}
