package SWP301.Furniture_Moving_Project.repository;

import SWP301.Furniture_Moving_Project.model.FurnitureItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FurnitureItemRepository extends JpaRepository<FurnitureItem, Integer> {
}
